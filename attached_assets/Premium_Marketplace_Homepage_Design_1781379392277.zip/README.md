
  # Premium Marketplace Homepage Design

  This is a code bundle for Premium Marketplace Homepage Design. The original project is available at https://www.figma.com/design/E2wkr3gemmD7JO756X9y7u/Premium-Marketplace-Homepage-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  