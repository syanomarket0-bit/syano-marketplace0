import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { PopularCategories } from './components/PopularCategories';
import { FeaturedDeals } from './components/FeaturedDeals';
import { TrustedStores } from './components/TrustedStores';
import { TrendingProducts } from './components/TrendingProducts';
import { NewArrivals } from './components/NewArrivals';
import { JoinSection } from './components/JoinSection';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div
      className="min-h-screen bg-[#080808]"
      style={{
        scrollbarWidth: 'thin',
        scrollbarColor: 'rgba(255,255,255,0.08) transparent',
      }}
    >
      <style>{`
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.08); border-radius: 2px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.14); }
        html { scroll-behavior: smooth; }
      `}</style>

      <Header />

      <main>
        <HeroSection />
        <PopularCategories />
        <FeaturedDeals />
        <TrustedStores />
        <TrendingProducts />
        <NewArrivals />
        <JoinSection />
      </main>

      <Footer />
    </div>
  );
}
