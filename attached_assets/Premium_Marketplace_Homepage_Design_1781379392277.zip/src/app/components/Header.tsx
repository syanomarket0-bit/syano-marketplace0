import { useState, useEffect } from 'react';
import { Search, ChevronDown } from 'lucide-react';

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      style={{ direction: 'rtl', fontFamily: "'Cairo', sans-serif" }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#080808]/98 backdrop-blur-2xl border-b border-white/[0.06] shadow-2xl shadow-black/50'
          : 'bg-[#080808]/80 backdrop-blur-xl border-b border-white/[0.04]'
      }`}
    >
      <div className="max-w-[1400px] mx-auto px-10 h-[72px] flex items-center gap-6">

        {/* Logo */}
        <a href="#" className="flex items-center gap-2.5 flex-shrink-0 group">
          <div className="relative">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-500/25 group-hover:shadow-emerald-500/40 transition-all duration-300">
              <span style={{ fontFamily: "'Cairo', sans-serif", fontWeight: 800 }} className="text-black text-sm leading-none">S</span>
            </div>
            <div className="absolute -inset-0.5 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 opacity-0 group-hover:opacity-20 blur transition-all duration-300" />
          </div>
          <div className="flex flex-col leading-none">
            <span style={{ fontWeight: 800, letterSpacing: '0.08em' }} className="text-white text-lg">SYANO</span>
            <span style={{ fontWeight: 400, fontSize: '10px' }} className="text-emerald-400/80 tracking-widest">سوق سوريا</span>
          </div>
        </a>

        {/* Nav links */}
        <nav className="flex items-center gap-1 me-2">
          {[
            { label: 'الرئيسية', active: true },
            { label: 'الفئات', hasDropdown: true },
            { label: 'المتاجر', hasDropdown: false },
            { label: 'العروض', hasDropdown: false },
          ].map((item) => (
            <a
              key={item.label}
              href="#"
              className={`flex items-center gap-1 px-3.5 py-2 rounded-lg text-sm transition-all duration-200 ${
                item.active
                  ? 'text-white bg-white/[0.06]'
                  : 'text-white/55 hover:text-white/90 hover:bg-white/[0.04]'
              }`}
              style={{ fontWeight: 500 }}
            >
              {item.label}
              {item.hasDropdown && <ChevronDown className="w-3.5 h-3.5 opacity-50" />}
            </a>
          ))}
        </nav>

        {/* Search bar */}
        <div className="flex-1 max-w-[420px]">
          <div
            className={`flex items-center gap-3 rounded-full border transition-all duration-200 ${
              searchFocused
                ? 'bg-white/[0.07] border-emerald-500/40 shadow-[0_0_0_3px_rgba(16,185,129,0.08)]'
                : 'bg-white/[0.05] border-white/[0.08] hover:border-white/[0.12]'
            }`}
          >
            <Search className="w-4 h-4 text-white/30 flex-shrink-0 ms-4" />
            <input
              type="text"
              placeholder="ابحث عن منتجات، متاجر، أو فئات..."
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setSearchFocused(false)}
              style={{ direction: 'rtl', fontFamily: "'Cairo', sans-serif", fontWeight: 400, fontSize: '14px' }}
              className="flex-1 bg-transparent text-white/80 placeholder-white/25 py-2.5 pe-3 outline-none"
            />
          </div>
        </div>

        {/* Spacer */}
        <div className="flex-1" />

        {/* Auth actions */}
        <div className="flex items-center gap-3 flex-shrink-0">
          <button
            style={{ fontWeight: 500, fontSize: '14px' }}
            className="text-white/60 hover:text-white/90 transition-colors px-3 py-2"
          >
            تسجيل الدخول
          </button>
          <button
            style={{ fontWeight: 600, fontSize: '14px' }}
            className="bg-emerald-500 hover:bg-emerald-400 text-black px-5 py-2.5 rounded-full transition-all duration-200 hover:shadow-lg hover:shadow-emerald-500/25 active:scale-95"
          >
            إنشاء حساب
          </button>
        </div>

      </div>
    </header>
  );
}
